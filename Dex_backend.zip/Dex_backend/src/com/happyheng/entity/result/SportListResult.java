package com.happyheng.entity.result;

import java.util.List;


public class SportListResult {
	private int result;
	private List<Integer> data;
	

	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	public List<Integer> getData() {
		return data;
	}
	public void setData(List<Integer> data) {
		this.data = data;
	}
	
}
