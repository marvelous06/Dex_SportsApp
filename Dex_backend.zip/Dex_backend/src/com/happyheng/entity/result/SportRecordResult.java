package com.happyheng.entity.result;

public class SportRecordResult {
	
	private int code;
	private long sportId;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public long getSportId() {
		return sportId;
	}
	public void setSportId(long sportId) {
		this.sportId = sportId;
	}
	
}
