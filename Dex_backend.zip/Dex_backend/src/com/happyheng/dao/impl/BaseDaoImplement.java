package com.happyheng.dao.impl;

public class BaseDaoImplement {
	
	
	/**
	 * 下为返回的码
	 */
	
	
	
	
	
	/**
	 * 下为SQL的错误码
	 */
	//MySql重复插入的错误码
	public static final int SQL_ERROR_CODE_DUPLICATE = 1062;
}
