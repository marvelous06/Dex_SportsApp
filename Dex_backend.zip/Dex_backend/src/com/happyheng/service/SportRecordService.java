package com.happyheng.service;

public interface SportRecordService {
	public int record(int sportId, double posx, double posy, String location);
}
