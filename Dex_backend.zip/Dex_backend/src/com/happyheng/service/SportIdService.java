package com.happyheng.service;

import com.happyheng.entity.result.SportRecordResult;

public interface SportIdService {
	public SportRecordResult getSportId(String userKey);
}
